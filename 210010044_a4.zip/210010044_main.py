"""
main.py is the main script that runs the simulation. It initializes the flow field, calls the van_Leer function to solve the 1D Euler equations, and plots the results.
"""

# Import libraries

import numpy as np
import van_Leer
from params import *
import initial_cond as ic
import plotter as pl

ic.initialize() # Initialize the flow field

U_new = van_Leer.van_Leer(U, F, N, t_end) # Solve the 1D Euler equations

# Extract the solution
rhos = U_new[0, :]
us = U_new[1, :]/rhos
ps = (gamma-1)*(U_new[2, :] - 0.5*rhos*us**2)
Ts = ps/(rhos*R)
Ms = us/np.sqrt(gamma*R*Ts)

pl.plotter(xs, us, ps, Ts, Ms, rhos*10**5)  # Plot the numerical and exact solutions

