"""
Plotter module to plot the numerical and exact solutions for the shock tube problem.
"""

# Import necessary libraries

import matplotlib.pyplot as plt
import pandas as pd
from params import gamma , R
import numpy as np


# Load the exact solution data

data = pd.read_csv('exact_solution_shock_tube.csv')
xs_exact = data['x']
us_exact = data['u']
ps_exact = data['P']
Ts_exact = data['T']
rhos_exact = data['rho']
a_exact = np.sqrt(gamma*R*Ts_exact)
Ms_exact = us_exact/a_exact


# Function to plot the numerical and exact solutions

def plotter(xs, us, ps, Ts, Ms, rhos):
    font = {'family': 'serif', 'weight': 'normal', 'size': 12}
    plt.rc('font', **font)

    # Plotting
    plt.figure(figsize=(12, 10))  # Adjust figure size for better readability

    # Subplot for Velocity
    plt.subplot(2, 2, 1)
    plt.plot(xs, us, label='Numerical Velocity')
    plt.plot(xs_exact, us_exact, label='Exact Velocity', linestyle='--')
    plt.xlabel('x')
    plt.ylabel('Velocity (m/s)')
    plt.title('Velocity Profile')
    plt.minorticks_on()
    plt.grid()
    plt.legend()

    # Subplot for Pressure
    plt.subplot(2, 2, 2)
    plt.plot(xs, ps*101325, label='Numerical Pressure')
    plt.plot(xs_exact, ps_exact, label='Exact Pressure', linestyle='--')
    plt.xlabel('x')
    plt.ylabel('Pressure (Pa)')
    plt.title('Pressure Profile')
    plt.minorticks_on()
    plt.grid()
    plt.legend()

    # Subplot for Temperature
    plt.subplot(2, 2, 3)
    plt.plot(xs, Ts, label='Numerical Temperature')
    plt.plot(xs_exact, Ts_exact, label='Exact Temperature', linestyle='--')
    plt.xlabel('x')
    plt.ylabel('Temperature (K)')
    plt.title('Temperature Profile')
    plt.minorticks_on()
    plt.grid()
    plt.legend()

    # Subplot for Mach number
    plt.subplot(2, 2, 4)
    plt.plot(xs, Ms, label='Numerical Mach number')
    plt.plot(xs_exact, Ms_exact, label='Exact Mach number', linestyle='--')
    plt.xlabel('x')
    plt.ylabel('Mach number (-)')
    plt.title('Mach Number Profile')
    plt.minorticks_on()
    plt.grid()
    plt.legend()

    # Add overall title for the figure
    plt.suptitle('Numerical and Exact Solutions for Shock Tube Problem')

    # Adjust layout to prevent overlap
    plt.tight_layout()

    plt.savefig('shock_tube_4.png')
    plt.show()

    # Plot for Density
    plt.plot(xs, rhos, label='Numerical Density')
    plt.plot(xs_exact, rhos_exact, label='Exact Density', linestyle='--')
    plt.xlabel('x')
    plt.ylabel('Density (kg/m^3)')
    plt.title('Density Profile')
    plt.minorticks_on()
    plt.grid()
    plt.legend()

    # Show the plot
    plt.savefig('shock_tube_density.png')
    plt.show()