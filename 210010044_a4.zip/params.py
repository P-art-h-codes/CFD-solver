"""
This file contains the parameters for the simulation.
"""

## Import libraries

import numpy as np

""" Parameters:                Discription:                                    : Data Type"""
N = 201                        # number of grid points (excluding ghost cells) : integer
L = 1.0                        # length of the domain                          : float 
dx = L/(N-1)                   # grid spacing                                  : float
nu = 0.1                       # CFL number (<1 for stability)                 : float
gamma = 1.4                    # specific heat ratio                           : float
R = 287.0                      # specific gas constant                         : float
t_end = 0.75 * 10**(-3)        # end time of simulation                        : float
xs = np.linspace(0, L, N+2)    # grid points                                   : numpy 1D array (N+2)
ps = np.zeros(N+2)             # pressure                                      : numpy 1D array (N+2)
us = np.zeros(N+2)             # velocity                                      : numpy 1D array (N+2)
Ts = np.zeros(N+2)             # temperature                                   : numpy 1D array (N+2)
Ms = np.zeros(N+2)             # Mach number                                   : numpy 1D array (N+2)
rhos = np.zeros(N+2)           # density                                       : numpy 1D array (N+2)
U = np.zeros((3, N+2))         # conserved variables (rho, rho*u, E)           : numpy 2D array (3, N+2)
F = np.zeros((3, N+2))         # fluxes (rho*u, rho*u*u +p, (E+p)*u)           : numpy 2D array (3, N+2)