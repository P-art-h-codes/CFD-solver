"""
Initializes the variables for the shock tube problem.
"""

import numpy as np
from params import *

def initialize():
    """ Function to initialize the variables for the shock tube problem.
    Args:
    None

    Returns:
    None
    """
    ## Initial conditions
    # Left state
    ps[:N//2] = 5.0
    us[:N//2] = 0.0
    Ts[:N//2] = 300.0
    Ms[:N//2] = 0.0
    rhos[:N//2] = ps[:N//2]/(R*Ts[:N//2])

    # Right state
    ps[N//2:] = 1.0
    us[N//2:] = 0.0
    Ts[N//2:] = 300.0
    Ms[N//2:] = 0.0
    rhos[N//2:] = ps[N//2:]/(R*Ts[N//2:])

    ## Boundary conditions
    # Left boundary
    ps[0] = ps[1]
    us[0] = us[1]
    Ts[0] = Ts[1]
    rhos[0] = rhos[1]

    # Right boundary
    ps[-1] = ps[-2]
    us[-1] = us[-2]
    Ts[-1] = Ts[-2]
    rhos[-1] = rhos[-2]

    # Compute the conserved variables
    U[0, :] = rhos
    U[1, :] = rhos*us
    U[2, :] = 0.5*rhos*us**2 + ps/(gamma-1)

    # Compute the fluxes
    F[0, :] = rhos*us
    F[1, :] = rhos*us**2 + ps
    F[2, :] = 0.5*rhos*us**3 + us*ps/(gamma-1)