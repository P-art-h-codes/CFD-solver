# Shock Tube Simulation

This repository contains a Python implementation of a shock tube simulation using the van-Leer Flux Vector Splitting (FVS) method 
to solve the 1D Euler equations. The simulation initializes a shock tube with specified initial and boundary conditions, performs 
the numerical solution, and plots the results against an exact solution for validation.

## Files Structure

The repository contains the following files:

- `210010044_main.py`: Main script that runs the simulation. It initializes the flow field, solves the 1D Euler equations using the van-Leer method, and plots the numerical and exact solutions.
- `initial_cond.py`: Module for initializing the shock tube problem with specified initial and boundary conditions.
- `params.py`: Contains parameters and constants used in the simulation (e.g., grid size, domain length, specific heat ratio).
- `plotter.py`: Module for plotting the numerical and exact solutions of the shock tube problem. Also saves the file
- `van_Leer.py`: Implementation of the van-Leer Flux Vector Splitting (FVS) method to solve the 1D Euler equations.
- `exact_solution_shock_tube.csv`: CSV file containing exact soultions for Pressure, Temperature, Mach Number, Density and Velocity
- `shock_tube.png`: Four subplots and a single plot comparing exact and numerical solutions for Pressure, Temperature, Mach Number, Density and Velocity (NOTE: generated after running code)

## Running the Code

1. Ensure you have Python installed on your system.
2. Download the ZIP file and extract its contents.
3. Navigate to the directory containing the script files.
4. Open a terminal or command prompt in this directory.
5. Run the following command to execute the script: python 210010044_main.py

## Output

Upon running the script, the following outputs will be generated:

1. shock_tube_4.png:
- Four subplots comparing exact and numerical solutions for Pressure, Temperature, Mach Number and Velocity
2. shock_tube_density.png
- A plot comparing eact and numerical solution for Density

    These are attached in report as well

## Dependencies

The script relies on the following Python libraries:
- numpy
- matplotlib
- pandas

These libraries can be installed via pip if not already present

### Note: Ensure that the parameters in the code are adjusted according to your specific problem requirements before running the script.

For any issues or inquiries, please contact Parth Nawkar (210010044) at 210010044@iitb.ac.in

Thank You !!!