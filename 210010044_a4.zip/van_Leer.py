"""This file contains the implementation of the van-Leer Flux Vector Splitting"""

# Import libraries

import numpy as np
from params import gamma, nu, dx

def Boundary_Conditions(U, N):
    """ Function to implement the boundary conditions
    Args:
    U (numpy 2D array): Conserved variables
    N (int): Number of grid points

    Returns:
    U (numpy 2D array): Conserved variables with boundary conditions implemented
    """
    U[0, 1] = U[0, 0]
    U[1, 1] = U[1, 0]
    U[2, 1] = U[2, 0]
    
    U[0, N] = U[0, N+1]
    U[1, N] = U[1, N+1]
    U[2, N] = U[2, N+1]
    
    return U


def van_Leer(U, F, N, t_end):

    """ Function to implement the van-Leer Flux Vector Splitting (FVS) method
    Args:
    U (numpy 2D array): Conserved variables
    F (numpy 2D array): Fluxes
    N (int): Number of grid points
    dx  (float): Grid spacing
    gamma (float): Specific heat ratio
    t_end (float): End time of simulation
    nu (float): CFL number

    Returns:
    U (numpy 2D array): Conserved variables with boundary conditions implemented
    """

    time = 0
    while (time < t_end):
        

        U = Boundary_Conditions(U, N) # Implement the boundary conditions

        # Extract the conserved variables
        rho = U[0]
        u = U[1]/rho
        p = (gamma-1)*(U[2] - 0.5*rho*u**2)
        a = np.sqrt(gamma*p/rho)
        M = u/a
        F[0] = rho*u
        F[1] = rho*u**2 + p
        F[2] = u*(U[2] + p)

        F_p = np.zeros((3, N+1))
        F_m = np.zeros((3, N+1))
   
        # Compute the time step
        lambda_max = max(abs(u) + a)
        dt = nu*dx/lambda_max
        time = time + dt

        for i in range(1, N+1):
            
            # Compute the fluxes
            if M[i] <= -1:
                F_p[:,i] = 0
                F_m[:,i] = F[:,i]

            elif M[i] >= 1:
                F_p[:,i] = F[:,i]
                F_m[:,i] = 0

            else:
                multiplier = 0.25*rho[i]*a[i]*(M[i]+1)**2

                F_p[0,i] = multiplier
                F_p[1,i] = multiplier*(2*a[i]/gamma)*(1 + (gamma-1)*M[i]/2)
                F_p[2,i] = multiplier*(2*a[i]**2/(gamma**2 - 1))*(1 + (gamma-1)*M[i]/2)**2

                F_m[:,i] = F[:,i] - F_p[:,i]
    
        # Update the conserved variables
        for i in range(1, N):
            U[:, i] = U[:, i] - dt/dx*(F_p[:, i] - F_p[:, i-1]) - dt/dx*(F_m[:, i+1] - F_m[:, i])
    
    return U