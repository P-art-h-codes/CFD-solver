""" This module contains functions to transform computational domain to physical domain and vice versa. """ 

# importing the necessary libraries

import numpy as np
import copy
import Derivatives as D
from params import venturi_start, venturi_end, dxhi, deta


def comp_to_physical(xhi, eta):
    """
    This function transforms computational domain to physical domain.
    """
    x = 4*xhi

    if xhi > 0.25 and xhi < 0.75:
        y = eta*(1 - 0.1 * (1 - np.cos((4*xhi - 1) * np.pi))) + 0.1 * (1 - np.cos((4*xhi - 1) * np.pi))
    else:
        y = eta
    return x, y


def Computational_Laplace(T, tol = 0.00001, N = 101, M = 26):

    """
    This function solves the stream equation using the Point-Gauss-Seidel method.
    
    Parameters:
    -----------
    T: 2D array
        Initial Stream Potential distribution
    N: int
        Number of grid points in the xhi direction
    M: int
        Number of grid points in the eta direction
    tol: float
        Tolerance for convergence (0.00001)
        
    Returns:
    --------
    T: 2D array
        Stream function distribution after solving the heat equation
    iter_count: int
        Number of iterations
    error: array
        Error at each iteration
    """


    # Initialize the error list
    error = []
    
    # Initialize the error grid
    err = np.zeros((N, M))
    
    # Initialize the iteration counter
    iter_count = 0

    dd = D.Derivatives_matrix(N,M)
        
    # Iterate until the error is less than the tolerance
    while True:

        apply_boundary_conditions(T, N, M)

        T_old = copy.deepcopy(T)

        # Update the temperature distribution
        for eta in range(1, M-1):
            for xhi in range(1, venturi_start):
            
                denomintor = 2*(1/(16*dxhi**2) + 1/(deta**2))
                
                numerator = (T[xhi+1, eta] + T[xhi-1, eta])/(16*dxhi**2) + (T[xhi, eta+1] + T[xhi, eta-1])/(deta**2)

                T[xhi, eta] = numerator/denomintor

            for xhi in range(venturi_start ,venturi_end):
           
                denomintor = 2*(dd[xhi,eta,0]**2 + dd[xhi,eta,1]**2)/dxhi**2 + 2*(dd[xhi,eta,2]**2 + dd[xhi,eta,3]**2)/deta**2

                D0 = dd[xhi,eta,0] # d_xhi_d_x
                D1 = dd[xhi,eta,1] # d_xhi_d_y
                D2 = dd[xhi,eta,2] # d_eta_d_x
                D3 = dd[xhi,eta,3] # d_eta_d_y

                numerator = ((T[xhi+1, eta] + T[xhi-1, eta])*(D0**2 + D1**2)/(dxhi**2)) \
                + ((T[xhi, eta+1] + T[xhi, eta-1])*(D2**2 + D3**2)/(deta**2)) \
                + (2*(T[xhi+1, eta+1] + T[xhi-1, eta-1] - T[xhi-1, eta+1] - T[xhi+1, eta-1])*(D0*D2 + D1*D3)/(4*dxhi*deta))\
                + ((T[xhi+1, eta] - T[xhi-1, eta]) * (D0**2 + D1**2)/(2*dxhi)) \
                + ((T[xhi, eta+1] - T[xhi, eta-1]) * (D2**2 + D3**2)/(2*deta))

                T[xhi, eta] = numerator/denomintor
        

            for xhi in range(venturi_end, N-1):
           
                denomintor = 2*(1/(16*dxhi**2) + 1/(deta**2))
                
                numerator = (T[xhi+1, eta] + T[xhi-1, eta])/(16*dxhi**2) + (T[xhi, eta+1] + T[xhi, eta-1])/(deta**2)

                T[xhi, eta] = numerator/denomintor

        # Update the error grid
        for i in range(1, N-1):
            for j in range(1, M-1):
                err[i, j] = T[i, j] - T_old[i, j]
        
        # Update the iteration counter
        iter_count += 1
        
        # Save Error for this Iteration
        error.append(np.max(np.abs(err)))

        # Check for convergence
        if np.max(np.abs(err)) < tol:
            print('Converged after', iter_count, 'iterations')
            apply_boundary_conditions(T, N, M)
            break
    
    return T, iter_count, np.array(error)

def apply_boundary_conditions(T, N = 101, M = 26):
    T[:,0] = 0
    T[:,M-1] = 100
    for i in range(M):
        T[0, i] = i*100/(M-1)
        T[N-1, i] = i*100/(M-1)

def initialize_stream_function(N = 101, M = 26):
    T = np.zeros((N, M))
    apply_boundary_conditions(T, N, M)
    return T