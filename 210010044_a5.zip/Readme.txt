# Venturi Tube Simulation

This repository contains a Python implementation of a stream function simulation using Finite Difference Method (FDM) 
to solve fluid flow equations. The simulation initializes a grid, calculates the stream function, solves the Laplace equation 
numerically using Point Gauss Siedel Method, and visualizes the results.

## Files Structure

The repository contains the following files:

- `210010044_main.py`: Main script that initializes the grid, stream function, and solves the Laplace equation, and plots all the results
- `Transforms.py`: Module containing the Laplace solver, helper functions and functions to transform computational domain to physical domain
- `params.py`: Contains parameters and constants used in the simulation (e.g., grid size, Venturi length).
- `Derivatives.py`: Module for calculating derivatives required for the Laplace equation solver
- Images : all the required result plots

## Running the Code

1. Ensure you have Python installed on your system.
2. Download the ZIP file and extract its contents.
3. Navigate to the directory containing the script files.
4. Open a terminal or command prompt in this directory.
5. Run the following command to execute the script: python 210010044_main.py
6. Result Plots are saved in same directory

## Output

Upon running the script, the following outputs will be generated:

- `grid.png`: Visualization of the initialized grid.
- `stream_function_initial.png`: Contour plot of the initial stream function.
- `stream_function_final.png`: Contour plot of the stream function after solving the Laplace equation.
- `log_error.png`: Plot of log(error) versus iteration during the numerical solution.
- `velocity_field.png`: Contour plot of the calculated velocity field.
- `u_velocity.png`: Plot of u-velocity at specific x locations.
- `v_velocity.png`: Plot of v-velocity at specific x locations.
- `velocity_field_quiver.png`: Quiver plot showing the velocity field.
- `total_velocity.png`: Plot of total velocity along specific x locations.

    These are attached in report as well

## Dependencies

The script relies on the following Python libraries:
- numpy
- matplotlib

These libraries can be installed via pip if not already present

### Note: Ensure that the parameters in the code are adjusted according to your specific problem requirements before running the script.

For any issues or inquiries, please contact Parth Nawkar (210010044) at 210010044@iitb.ac.in

Thank You !!!