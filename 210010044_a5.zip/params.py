""" Description: This file contains the parameters for the simulation."""

N =101                      # number of grid points in the xhi direction
M = 26                      # number of grid points in the eta direction
dxhi = 1/(N-1)              # grid spacing in the xhi direction
deta = 1/(M-1)              # grid spacing in the eta direction
venturi_start = int(N*1/4)  # start of the venturi
venturi_end = int(N*3/4)    # end of the venturi