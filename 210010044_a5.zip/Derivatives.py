"""
This file contains the functions to calculate the derivatives d_xhi_d_x, d_xhi_d_y, d_eta_d_x, d_eta_d_y
"""

# importing the necessary libraries

import numpy as np
from params import venturi_start, venturi_end, N, M


def d_x_d_xhi(xhi, eta):
    return 4 # analytically calculated

def d_x_d_eta(xhi, eta):
    return 0 # analytically calculated

def d_y_d_xhi(xhi, eta):
    xhi_ = xhi/(N-1) # converting from index to actual value
    eta_ = eta/(M-1) # converting from index to actual value

    return (1 - eta_)*(0.1 * np.pi * 4 * np.sin((4*xhi_ - 1) * np.pi)) # analytically calculated

def d_y_d_eta(xhi, eta):
    xhi_ = xhi/(N-1) # converting from index to actual value
    eta_ = eta/(M-1) # converting from index to actual value

    return 1 - 0.1 *(1 - np.cos((4*xhi_ - 1) * np.pi)) # analytically calculated

def Jacobian(xhi, eta):
    xhi_ = xhi/(N-1) # converting from index to actual value
    eta_ = eta/(M-1) # converting from index to actual value

    return d_x_d_xhi(xhi_, eta_)*d_y_d_eta(xhi_, eta_) - d_x_d_eta(xhi_, eta_)*d_y_d_xhi(xhi_, eta_)

def d_xhi_d_x(xhi, eta):
    return d_y_d_eta(xhi, eta)/Jacobian(xhi, eta)

def d_xhi_d_y(xhi, eta):
    return -d_x_d_eta(xhi, eta)/Jacobian(xhi, eta)

def d_eta_d_x(xhi, eta):
    return -d_y_d_xhi(xhi, eta)/Jacobian(xhi, eta)

def d_eta_d_y(xhi, eta):
    return d_x_d_xhi(xhi, eta)/Jacobian(xhi, eta)

def Derivatives_matrix(N,M):
    """
    This function returns the derivatives matrix D to be used in the Laplace equation solver
    """

    D = np.zeros((N,M,4))
    for xhi in range(venturi_start,venturi_end):
        for eta in range(1,M-1):
            D[xhi,eta,0] = d_xhi_d_x(xhi,eta)
            D[xhi,eta,1] = d_xhi_d_y(xhi,eta)
            D[xhi,eta,2] = d_eta_d_x(xhi,eta)
            D[xhi,eta,3] = d_eta_d_y(xhi,eta)
    return D