import numpy as np
import copy

def Gauss_Seidel(T_grid, I, J, beta, tol = 0.00001):
    """
    This function solves the 2D heat equation using the Point-Gauss-Seidel method.
    
    Parameters:
    -----------
    T_grid: 2D array
        Initial temperature distribution
    dx: float
        Grid spacing in the x direction
    dy: float
        Grid spacing in the y direction
    I: int
        Number of grid points in the x direction
    J: int
        Number of grid points in the y direction
    beta: float
        Ratio of dx to dy
    tol: float
        Tolerance for convergence (0.00001)
        
    Returns:
    --------
    T: 2D array
        Temperature distribution after solving the heat equation
    iter_count: int
        Number of iterations
    error: array
        Error at each iteration
    """
    
    # Initialize the temperature distribution
    T_new = copy.deepcopy(T_grid)

     # Initialize the error list
    error = []
    
    # Initialize the error grid
    err = np.zeros((I, J))
    
    # Initialize the iteration counter
    iter_count = 0
    
    # Iterate until the error is less than the tolerance
    while True:
        
        # Update the temperature distribution
        for i in range(1, I-1):
            for j in range(1, J-1):
                T_new[i, j] = (1 / (2 * (1 + beta**2))) * (T_grid[i+1, j] + T_new[i-1, j] + beta**2 * (T_grid[i, j+1] + T_new[i, j-1]))
        
        # Update the error grid
        for i in range(1, I-1):
            for j in range(1, J-1):
                err[i, j] = T_new[i, j] - T_grid[i, j]
        # Update the temperature distribution
        T_grid = copy.deepcopy(T_new)
        
        # Update the iteration counter
        iter_count += 1
        
        # Save Error for this Iteration
        error.append(np.max(np.abs(err)))

        # Check for convergence
        if np.max(np.abs(err)) < tol:
            print('Converged after', iter_count, 'iterations')
            break
    
    return T_grid, iter_count, np.array(error)