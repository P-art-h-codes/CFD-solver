"""This script is the main script that initializes the grid, stream function and solves the stream equation using the Laplace equation."""

#importing libraries
import numpy as np
import matplotlib.pyplot as plt
import Transforms as T
import Derivatives as D
from params import N, M, venturi_start, venturi_end


#initializing grid points
etas = np.zeros((N,M))
xhis = np.zeros((N,M))
x = np.linspace(0,4,N)
y = np.linspace(0,1,M)


for i in range(N):
    xhis[i,:] = x[i]

for j in range(M):
    etas[:,j] = y[j]

for i in range(venturi_start,venturi_end):
    base_height = 0.1*(1 - np.cos((x[i]-1)*np.pi))
    for j in range(26):
        etas[i,j] = (1 - base_height)*(j/25) + base_height

#visualizing the grid
plt.figure(figsize=(10,5))
plt.scatter(xhis,etas,c='b', marker='o', s=2)
plt.plot(xhis,etas,c='k',linewidth=0.5)
plt.xlabel('x')
plt.ylabel('y')
plt.title('Grid')
plt.savefig('grid.png')
plt.show()

#initializing the stream function
psi = T.initialize_stream_function()

# plotting the stream function
plt.figure(figsize=(10,5))
plt.contourf(xhis,etas,psi,100,cmap='jet')
plt.colorbar()
plt.xlabel('xhi')
plt.ylabel('eta')
plt.title('Stream Function')
plt.savefig('stream_function_initial.png')
plt.show()

#solving the stream equation
psi_end, iter_count, error = T.Computational_Laplace(psi, 0.00001, N, M)

plt.figure(figsize=(10,5))
plt.contourf(xhis,etas,psi_end,100,cmap='jet')
plt.colorbar()
plt.xlabel('xhi')
plt.ylabel('eta')
plt.title('Stream Function')

plt.savefig('stream_function_final.png')
plt.show()

# plotting the log(error) vs iteration

plt.figure(figsize=(10,5))
plt.plot(np.log(error))
plt.xlabel('Iteration')
plt.ylabel('Log(Error)')
plt.title('Log(Error) vs Iteration')
plt.savefig('log_error.png')
plt.show()

# calculating the velocity field

u = np.zeros((N,M))
v = np.zeros((N,M))

for i in range(1,N-1):
    for j in range(1,M-1):
        u[i,j] = (psi_end[i,j+1] - psi_end[i,j-1])/(x[i+1] - x[i-1])
        v[i,j] = -(psi_end[i+1,j] - psi_end[i-1,j])/(y[j+1] - y[j-1])

plt.figure(figsize=(10,5))
plt.contourf(xhis,etas,np.sqrt(u**2+v**2),50, cmap='jet')
plt.colorbar()
plt.xlabel('x')
plt.ylabel('y')
plt.title('Velocity Field')
plt.savefig('velocity_field.png')
plt.show()

# ploting u velocity at x = (0.5, 1.0,2.0, 3.0, 3.5)

plt.figure(figsize=(10,5))
plt.plot(y[1:M-1],u[13,1:M-1],label='x = 0.5')
plt.plot(y[1:M-1],u[25,1:M-1],label='x = 1.0')
plt.plot(y[1:M-1],u[50,1:M-1],label='x = 2.0')
plt.plot(y[1:M-1],u[75,1:M-1],label='x = 3.0')
plt.plot(y[1:M-1],u[87,1:M-1],label='x = 3.5')
plt.xlabel('y')
plt.ylabel('u')
plt.title('u velocity')
plt.legend()
plt.savefig('u_velocity.png')
plt.show()

# ploting v velocity at x = (0.5, 1.0, 2,0, 3.0, 3.5)

plt.figure(figsize=(10,5))
plt.plot(y[1:M-1],v[13,1:M-1],label='x = 0.5')
plt.plot(y[1:M-1],v[25,1:M-1],label='x = 1.0')
plt.plot(y[1:M-1],v[50,1:M-1],label='x = 2.0')
plt.plot(y[1:M-1],v[75,1:M-1],label='x = 3.0')
plt.plot(y[1:M-1],v[87,1:M-1],label='x = 3.5')
plt.xlabel('y')
plt.ylabel('v')
plt.title('v velocity')
plt.legend()
plt.savefig('v_velocity.png')
plt.show()

# Plot variations of total velocity along the mid-vertical-lines at locations x = 0.5, 1.0, 2.0, 3.0, 3.5 (quiver plot)

plt.figure(figsize=(10,5))
plt.quiver(xhis,etas,u,v)
plt.xlabel('x')
plt.ylabel('y')
plt.title('Velocity Field')
plt.savefig('velocity_field_quiver.png')
plt.show()

# Plot variations of total velocity along the mid-vertical-lines at locations x = 0.5, 1.0, 2.0, 3.0, 3.5 (value plot)

plt.figure(figsize=(10,5))
plt.plot(y[1:M-1],np.sqrt(u[13,1:M-1]**2 + v[13,1:M-1]**2),label='x = 0.5')
plt.plot(y[1:M-1],np.sqrt(u[25,1:M-1]**2 + v[25,1:M-1]**2),label='x = 1.0')
plt.plot(y[1:M-1],np.sqrt(u[50,1:M-1]**2 + v[50,1:M-1]**2),label='x = 2.0')
plt.plot(y[1:M-1],np.sqrt(u[75,1:M-1]**2 + v[75,1:M-1]**2),label='x = 3.0')
plt.plot(y[1:M-1],np.sqrt(u[87,1:M-1]**2 + v[87,1:M-1]**2),label='x = 3.5')
plt.xlabel('y')
plt.ylabel('Total Velocity')
plt.title('Total Velocity')
plt.legend()
plt.savefig('total_velocity.png')
plt.show()
