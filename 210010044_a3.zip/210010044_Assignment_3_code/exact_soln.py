import numpy as np

"""
Exact solution of the heat equation is calculated using the following function

Parameters:
    plate_grid: Initial temperature distribution
    alpha:      Thermal diffusivity   
    dt:         Time step
    timesteps:  Number of time steps
Returns:
    u: Temperature distribution at different time steps

"""
def exact(plate_grid, alpha,dt,timesteps):
  
    timesteps = int(timesteps)
    u=np.zeros((timesteps,len(plate_grid)))
    u[0]=plate_grid
               
    for i in range(1,timesteps):
        for j in range(1,50):
            x=0
            for m in range(1,101):
                x=x+(np.exp(-m*m*np.pi*np.pi*alpha*i*dt)*((1-np.power(-1,m))/(m*np.pi))*np.sin(np.pi*m*0.02*j))
            u[i][j]=200 + 2*(40-200)*x
        
        u[i][0]=200
        u[i][50]=200

    return u