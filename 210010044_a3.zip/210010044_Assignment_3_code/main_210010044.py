import numpy as np
import matplotlib.pyplot as plt
import FTCS as FTCS
import CN as CN
import exact_soln as exact
import os 

#Folder named 'plots' created 
if not os.path.exists('plots'):
    os.mkdir('plots')


## Grid Initialisation

def grid_init():

    ## Initialising the grid
    plate_grid = 40 * np.ones(51)

    ## Boundary Condition

    plate_grid[0] = 200
    plate_grid[-1] = 200
    return plate_grid

## Constants

dt = 60 # Stable time step dt < 76.9 sec
dx= 0.02
alpha = 2.6 * 10 **(-6) ## Thermal diffusivity

"""FTCS and CN methods are used to solve the heat equation and the results are compared with the exact solution"""

"""FTCS"""

plate_grid = grid_init() ## Setting grid back to intial state
solution_array_FTCS_1 = FTCS.FTCS(plate_grid, alpha, dx, dt, 0.1*3600/dt)

plate_grid = grid_init() ## Setting grid back to intial state
solution_array_FTCS_2 = FTCS.FTCS(plate_grid, alpha, dx, dt, 0.3*3600/dt)

plate_grid = grid_init() ## Setting grid back to intial state
solution_array_FTCS_3 = FTCS.FTCS(plate_grid, alpha, dx, dt, 0.5*3600/dt)

"""CN"""

plate_grid = grid_init() ## Setting grid back to intial state
solution_array_CN_1 = CN.CN(plate_grid, alpha, dx, dt, 0.1*3600/dt)

plate_grid = grid_init() ## Setting grid back to intial state
solution_array_CN_2 = CN.CN(plate_grid, alpha, dx, dt, 0.3*3600/dt)

plate_grid = grid_init() ## Setting grid back to intial state
solution_array_CN_3 = CN.CN(plate_grid, alpha, dx, dt, 0.5*3600/dt)
print(solution_array_CN_3[-1])

"""Exact Solution"""

plate_grid = grid_init() ## Setting grid back to intial state
solution_array_exact1 = exact.exact(plate_grid, alpha, dt, 0.1*3600/dt)

plate_grid = grid_init() ## Setting grid back to intial state
solution_array_exact2 = exact.exact(plate_grid, alpha, dt, 0.3*3600/dt)

plate_grid = grid_init() ## Setting grid back to intial state
solution_array_exact3 = exact.exact(plate_grid, alpha, dt, 0.5*3600/dt)



## x arrays to be used in plots 
x=np.arange(0, 1+ dx, dx)


# plots
"""Temperature distribution at different time steps are plotted and compared with the exact solution"""

plt.plot(x, solution_array_FTCS_1[-1], label = 'FTCS 0.1 hr')
plt.plot(x, solution_array_CN_1[-1], label = 'CN 0.1 hr')
plt.plot(x, solution_array_exact1[-1], label = 'Exact 0.1 hr')
plt.ylabel('Temperature ($^{o}$C)')
plt.xlabel('Location')
plt.legend()
plt.title('Temperature Distribution 0.1 hr')
plt.tight_layout()
plt.savefig('plots/compare1.png')
plt.close()

plt.plot(x, solution_array_FTCS_2[-1], label = 'FTCS 0.3 hr')
plt.plot(x, solution_array_CN_2[-1], label = 'CN 0.3 hr')
plt.plot(x, solution_array_exact2[-1], label = 'Exact 0.3 hr')
plt.ylabel('Temperature ($^{o}$C)')
plt.xlabel('Location')
plt.legend()
plt.title('Temperature Distribution 0.3 hr')
plt.tight_layout()
plt.savefig('plots/compare2.png')
plt.close()

plt.plot(x, solution_array_FTCS_3[-1], label = 'FTCS 0.5 hr')
plt.plot(x, solution_array_CN_3[-1], label = 'CN 0.5 hr')
plt.plot(x, solution_array_exact3[-1], label = 'Exact 0.5 hr')
plt.ylabel('Temperature ($^{o}$C)')
plt.xlabel('Location')
plt.legend()
plt.title('Temperature Distribution 0.5 hr')
plt.tight_layout()
plt.savefig('plots/compare3.png')
plt.close()

"""Temperature distribution at different time steps are plotted using FTCS method with unstable dt > 76.9 sec"""
# dt = 100 sec

plate_grid = grid_init() ## Setting grid back to intial state
solution_array_FTCS_unstable1 = FTCS.FTCS(plate_grid, alpha, dx, 100, 0.1*3600/100)

plate_grid = grid_init() ## Setting grid back to intial state
solution_array_FTCS_unstable2 = FTCS.FTCS(plate_grid, alpha, dx, 100, 0.3*3600/100)

plate_grid = grid_init() ## Setting grid back to intial state
solution_array_FTCS_unstable3 = FTCS.FTCS(plate_grid, alpha, dx, 100, 0.5*3600/100)

"""Unstable dt plots for FTCS method"""

plt.plot(x, solution_array_FTCS_unstable1[-1], label = 'FTCS 0.1 hr')
plt.ylabel('Temperature ($^{o}$C)')
plt.xlabel('Location')
plt.title('Temperature Distribution FTCS 0.1 hr using unstable dt')
plt.legend()
plt.tight_layout()
plt.savefig('plots/unstable_FTCS1.png')
plt.close()

plt.plot(x, solution_array_FTCS_unstable2[-1], label = 'FTCS 0.3 hr')
plt.ylabel('Temperature ($^{o}$C)')
plt.xlabel('Location')
plt.title('Temperature Distribution FTCS 0.3 hr using unstable dt')
plt.legend()
plt.tight_layout()
plt.savefig('plots/unstable_FTCS2.png')
plt.close()

plt.plot(x, solution_array_FTCS_unstable3[-1], label = 'FTCS 0.5 hr')
plt.ylabel('Temperature ($^{o}$C)')
plt.xlabel('Location')
plt.title('Temperature Distribution FTCS 0.5 hr using unstable dt')
plt.legend()
plt.tight_layout()
plt.savefig('plots/unstable_FTCS3.png')
plt.close()


# Error Comparison
"""Error between the exact solution and the numerical solution is plotted for FTCS and CN methods"""

error_FTCS_1 = (solution_array_exact1[-1] - solution_array_FTCS_1[-1])/solution_array_exact1[-1]
error_CN_1 = (solution_array_exact1[-1] - solution_array_CN_1[-1])/solution_array_exact1[-1]
plt.plot(x, error_FTCS_1)
plt.plot(x, error_CN_1)
plt.ylabel('Error')
plt.xlabel('Location')
plt.title('Error Comparison')
plt.legend(['FTCS 0.1 hr', 'CN 0.1 hr'])
plt.tight_layout()
plt.savefig('plots/error1.png')
plt.close()

error_FTCS_2 = (solution_array_exact2[-1] - solution_array_FTCS_2[-1])/solution_array_exact2[-1]
error_CN_2 = (solution_array_exact2[-1] - solution_array_CN_2[-1])/solution_array_exact2[-1]
plt.plot(x, error_FTCS_2)
plt.plot(x, error_CN_2)
plt.ylabel('Error')
plt.xlabel('Location')
plt.title('Error Comparison')
plt.legend(['FTCS 0.3 hr', 'CN 0.3 hr'])
plt.tight_layout()
plt.savefig('plots/error2.png')
plt.close()

error_FTCS_3 = (solution_array_exact3[-1] - solution_array_FTCS_3[-1])/solution_array_exact3[-1]
error_CN_3 = (solution_array_exact3[-1] - solution_array_CN_3[-1])/solution_array_exact3[-1]
plt.plot(x, error_FTCS_3)
plt.plot(x, error_CN_3)
plt.ylabel('Error')
plt.xlabel('Location')
plt.title('Error Comparison')
plt.legend(['FTCS 0.5 hr', 'CN 0.5 hr'])
plt.tight_layout()
plt.savefig('plots/error3.png')
plt.close()

#Thanks for reading!