import numpy as np

"""
FTCS method is used to solve the heat equation

Parameters:
    plate_grid: Initial temperature distribution
    alpha:      Thermal diffusivity   
    dx:         Grid spacing
    dt:         Time step
    timesteps:  Number of time steps

Returns:
    u: Temperature distribution at different time steps
"""
def FTCS(plate_grid, alpha, dx, dt,  timesteps):

    a = alpha * dt / (dx ** 2)
    timesteps = int(timesteps)
    nx = len(plate_grid)
    u = np.zeros((timesteps, nx))
    u[0] = plate_grid
    for n in range(1, timesteps):
        for i in range(1,50):
            u[n,i] = u[n-1,i] + a * (u[n-1,i+1] - 2 * u[n-1,i] + u[n-1,i-1])
        u[n,0] = 200
        u[n,-1] = 200
    return u