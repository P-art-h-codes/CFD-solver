import numpy as np

"""
Crank-Nicolson method is used to solve the heat equation

Parameters:
    plate_grid: Initial temperature distribution
    alpha:      Thermal diffusivity   
    dx:         Grid spacing
    dt:         Time step
    timesteps:  Number of time steps

Returns:
    u: Temperature distribution at different time steps

"""
def CN(plate_grid, alpha, dx, dt, time_steps):
    # Constants
    alpha = 2.6 * 10 **(-6) ## Thermal diffusivity
    a = 0.5 * alpha * dt / (dx ** 2)

    # Grid size
    nx = len(plate_grid)-2
    timesteps = int(time_steps)

    # Initialize the solution matrix
    u = np.zeros((timesteps, len(plate_grid)))

    # Set initial condition
    u[0] = plate_grid

    # Crank-Nicolson scheme

    # Create tridiagonal matrix
    A = np.diag(1 + 2 * a * np.ones(nx))
    A += np.diag(-a * np.ones(nx - 1), k=1)
    A += np.diag(-a * np.ones(nx - 1), k=-1)
    
    B = np.diag(1 - 2 * a * np.ones(nx))
    B += np.diag(a * np.ones(nx - 1), k=1)
    B += np.diag(a * np.ones(nx - 1), k=-1)

    for n in range(1, timesteps):
        
        """ 
        solve the system of equations (A*u[n] = B*u[n-1] + a*boundary_conditions) 
        uncomment and comment the next function to use this method
        """
        # u[n][1:-1] = np.linalg.solve(A, np.dot(B, u[n-1][1:-1]) + 2*a * np.array([200, *np.zeros(nx - 2), 200]))
        
        """ solve the system of equations using Thomas algorithm """
        # (more efficient than np.linalg.solve() for tridiagonal matrices)
        
        def thomas_algorithm(A, b):
            n = len(b)
            c = np.zeros(n-1)
            d = np.zeros(n)
            x = np.zeros(n)

            c[0] = A[0, 1] / A[0, 0]
            d[0] = b[0] / A[0, 0]

            for i in range(1, n-1):
                c[i] = A[i, i+1] / (A[i, i] - A[i, i-1] * c[i-1])
            
            for i in range(1, n):
                d[i] = (b[i] - A[i, i-1] * d[i-1]) / (A[i, i] - A[i, i-1] * c[i-1])
            
            x[n-1] = d[n-1]

            for i in range(n-2, -1, -1):
                x[i] = d[i] - c[i] * x[i+1]

            return x

        # solve the system of equations using Thomas algorithm
        u[n][1:-1] = thomas_algorithm(A, np.dot(B, u[n-1][1:-1]) + 2* a * np.array([200, *np.zeros(nx - 2), 200]))
        
        # Apply boundary conditions
        u[n][0] = 200
        u[n][-1] = 200
                
    return u