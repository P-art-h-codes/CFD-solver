# README.txt

This repository contains a Python script to solve the heat equation using Finite Difference Methods 
(FTCS and CN) and compare the results with the exact solution. 
The temperature distribution at different time steps is plotted and error comparisons are provided.

### Running the Code

1. Ensure you have Python installed on your system.
2. Download the ZIP file and extract its contents.
3. Navigate to the directory containing the script files.
4. Open a terminal or command prompt in this directory.
5. Run the following command to execute the script: python main_210010044.py


### Output

Upon running the script, the following outputs will be generated:

1. Plots Folder: A folder named 'plots' will be created in the current directory if it doesn't exist. This folder will contain all the generated plots.

2. Plots:
- Three plots comparing the temperature distribution at different time steps for both FTCS and CN methods with the exact solution will be generated. 
    (compare1.png, compare2.png, compare3.png)
- Three additional plots showing the temperature distribution for unstable time steps using the FTCS method will also be generated. 
    (unstable_FTCS1.png, unstable_FTCS2.png, unstable_FTCS3.png)
- Error comparison plots between the numerical solutions (FTCS and CN) and the exact solution will be generated. 
    (error1.png, error2.png, error3.png)

    These are attached in report as well

### File Structure

The repository contains the following files:

1. main.py:         The main Python script that solves the heat equation, generates plots, and compares results.
2. FTCS.py:         Module implementing the FTCS method for solving the heat equation.
3. CN.py:           Module implementing the Crank-Nicolson method for solving the heat equation.
4. exact_soln.py:   Module providing the exact solution for comparison.
5. plots (folder):  This folder will be generated automatically and will contain all the generated plots.
6. README.txt:      This file, providing instructions on how to run the code and explaining the file structure.

### Dependencies

The script relies on the following Python libraries:
- numpy
- matplotlib
- os

These libraries can be installed via pip if not already present


### Note

Ensure that the parameters in the code, such as grid size (dx), time step (dt), etc., are adjusted according to your specific problem requirements before running the script.

For any issues or inquiries, please contact Parth Nawkar (210010044) at 210010044@iitb.ac.in
